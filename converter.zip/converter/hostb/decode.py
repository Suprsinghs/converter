import base64
import os
encodedFileSrcDir = '/app/xml_enc/'
targetDir = '/app/xml_dec/'


with os.scandir(encodedFileSrcDir) as entries:
    for entry in entries:
        print(entry.name)
        fileExt = entry.name[-8:]
        if entry.is_file() and fileExt == '.encoded':
            xmlEncodedFileForReading = open(encodedFileSrcDir + entry.name, "r")
            base64_string_1 = xmlEncodedFileForReading.read()
            base64_bytes_1 = base64_string_1.encode("ascii")
            decoded_str_1 = base64.b64decode(base64_bytes_1)
            decoded = decoded_str_1.decode("ascii")
            # xml decoded file. Add file path before targetFileName. here I have passed an
            # empty string to represent pwd. For reading
            xmlDecodedFile = open(targetDir + entry.name + "_decoded.xml", "w")  # Base64 decode xml
            xmlDecodedFile.write(decoded)
            xmlDecodedFile.close()
            # delete files
            # os.remove("demofile.txt")

import json
import base64
import os
def json_to_xml(json_obj, line_spacing=""):
    result_list = list()
    json_obj_type = type(json_obj)
    if json_obj_type is list:
        for sub_elem in json_obj:
            result_list.append(json_to_xml(sub_elem, line_spacing))
        return "\n".join(result_list)
    if json_obj_type is dict:
        for tag_name in json_obj:
            sub_obj = json_obj[tag_name]
            result_list.append("%s<%s>" % (line_spacing, tag_name))
            result_list.append(json_to_xml(sub_obj, "\t" + line_spacing))
            result_list.append("%s</%s>" % (line_spacing, tag_name))
            # print(result_list)
        return "\n".join(result_list)
    return "%s%s" % (line_spacing, json_obj)

#os,scandir() accepts the path of the target directory empty param means pwd
# path till file location. empty means pwd
sourceDirPath = "/app/json/"
#targetDir = "/app/xml_dec/"
targetxmldir = "/app/xml_out/"
targetencdir = "/app/xml_enc/"
with os.scandir(sourceDirPath) as entries:
    for entry in entries:
        print(entry.name)
        isJon = entry.name[-5:]
        if entry.is_file() and isJon == '.json':
            print(entry.name)
            targetFileName = entry.name[:-5]
            with open(sourceDirPath+entry.name, "r") as s:  # open and read the json file
                data = json.load(s)
                # xml conversion start
                xmlStr = json_to_xml(data)
                # xml without encoding. Add file path before targetFileName. here I have passed an
                # empty string to represent pwd
                xmlFile = open(targetxmldir+targetFileName+".xml", "w")
                xmlFile.write(xmlStr)
                xmlFile.close()
                # Base64 encoded xml
                xml_bytes = xmlStr.encode("ascii")
                base64_bytes = base64.b64encode(xml_bytes)
                base64_string = base64_bytes.decode("ascii")
                # xml encoded file. Add file path before targetFileName. here I have passed an
                # empty string to represent pwd.
                xmlEncoded = open(targetencdir + targetFileName + "_xml.encoded", "w")
                xmlEncoded.write(base64_string)
                xmlEncoded.close()

